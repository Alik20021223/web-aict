export type QuesType = {
  id: string,
  questionTj: string,
  questionRu: string,
  questionEn: string,
  answerTj: string,
  answerRu: string,
  answerEn: string,
};

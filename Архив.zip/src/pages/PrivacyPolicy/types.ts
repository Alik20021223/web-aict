export type blockPrivacy = {
    id: number,
    name: string,
    describe: string,
}
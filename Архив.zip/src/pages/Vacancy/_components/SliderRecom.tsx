import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import 'swiper/css/navigation';
import { Autoplay } from 'swiper/modules';
import { RecomBlockVacancy } from './recomBlockVacancy';
import { VacancyApp } from './type';


export const RecomSlider = ({ data }: VacancyApp) => {

    return (
        <Swiper

            slidesPerView={1}
            autoplay={{
                delay: 2500,
                disableOnInteraction: false,
            }}
            modules={[Autoplay]}

        >
            {data.map((item) => (
                <SwiperSlide key={item.id}>
                    <RecomBlockVacancy data={item} />
                </SwiperSlide>
            ))}
        </Swiper>
    )
};

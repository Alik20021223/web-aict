import { useSelector } from "react-redux"
import { RootState } from "../../../state/store"
import { partnersBlockType } from "../../Partners/_compents/types"

interface PartnersBlockApp {
    data: partnersBlockType,
}

export const MainPartner = ({ data }: PartnersBlockApp) => {

    const urlHosting = useSelector((state: RootState) => state.aict.urlHosting)

    return (
        <div className="bg-white shadow-md border-2 border-[#D3D8E3] rounded-md h-full">
            <div className="py-14 px-12 w-full  flex justify-center">
                <div className="h-[200px] w-[350px]">
                    <img src={`${urlHosting}/${data.imagePath}`} alt={`${data.titleEn}-img`} className="w-full object-fit rounded-lg h-full max-w-full" />
                </div>
            </div>
        </div>
    )
}

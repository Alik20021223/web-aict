export type Tabs = {
    name: string,
    key: string,
    link: string,
}

export type PropsHeaderApp = {
    data: Tabs[]
}